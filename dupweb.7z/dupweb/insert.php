<?php

require 'conn.php';

$emp = $_GET['emp'];
$currentpassword = $_GET['currentpassword'];
$newpassword = $_GET['newpassword'];
$reenterpassword = $_GET['reenterpassword'];
$searchpin = '';
$searchquestion = '';
$answer = '';

// $emp = 'inserting';
// $currentpassword = 'inserting';
// $newpassword = 'inserting';
// $reenterpassword = 'inserting';
// $searchpin = 'inserting';
// $searchquestion = 'inserting';
// $answer = 'inserting';


$sql = "insert into data (emp,currentpassword,newpassword,reenterpassword,secretpin,question,answer)
        values('$emp','$currentpassword','$newpassword','$reenterpassword','$searchpin','$searchquestion','$answer'); ";
$result = mysqli_query($mysqli, $sql);
